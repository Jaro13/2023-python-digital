from shape import Circle

c1 = Circle(10,"blue",3,(2,3))
print(c1)
c1.change_border_color("red")
print(c1)
