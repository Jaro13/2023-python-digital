from bankaccount import BankAccount

acc1 = BankAccount(holder = "Alex", number = 123)
print(acc1)
# print(type(acc1))

# print(acc1.number)
# print(acc1.holder)
# print(acc1.balance)

# # acc2 = BankAccount(holder = "Bob", number = 567 , balance = 100)
# # print(acc2.number)
# # print(acc2.holder)
# # print(acc2.balance)
# print(acc1.balance)
# acc1.deposit(20)
# print(acc1.balance)
# acc1.withdraw(10)
# print(acc1.balance)
# acc1.withdraw(15)
# print(acc1.balance)