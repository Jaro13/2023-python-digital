def fire(rounds):
    print("Loading ammo...")
    print("...FIRING...")
    
    while rounds:
        print("🔥")
        rounds -= 1
    
    print("...no ammo!")