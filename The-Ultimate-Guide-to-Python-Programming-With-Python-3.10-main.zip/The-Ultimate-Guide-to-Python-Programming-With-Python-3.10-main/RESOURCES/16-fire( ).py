def fire(loaded):
    print("Loading ammo...")
    
    if loaded:
        print("...FIRING...")
        print("🔥")
        print("🔥")
        print("🔥")
    else:
        print("...no ammo!")