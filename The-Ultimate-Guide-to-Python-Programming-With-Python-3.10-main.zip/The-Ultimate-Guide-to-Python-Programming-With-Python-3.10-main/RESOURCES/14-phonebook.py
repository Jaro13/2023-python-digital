contacts = {
    "Dale": 99021,
    "Tim": 99117,
    "James": 98101
}

name = input("Search 🔎: ")

print(contacts[name])