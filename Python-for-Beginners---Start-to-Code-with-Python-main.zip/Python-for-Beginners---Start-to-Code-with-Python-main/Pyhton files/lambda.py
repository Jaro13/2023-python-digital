val = lambda a : a * 5
num1 = val(10)
print(num1)

val1 = lambda a,b : a * b
num2 = val1(10,20)
print(num2)

print(val1(3,9))