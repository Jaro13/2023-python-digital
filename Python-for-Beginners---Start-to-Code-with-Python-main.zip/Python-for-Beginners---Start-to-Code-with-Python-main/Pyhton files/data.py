a = True
#print(type(a))
b = False
#print(type(b))
#print(5>10)
#List Type
testList = [50,"100",True,50,"50"]
print("100" in testList)
#print(testList[1])
#print(len(testList))
#print(type(testList))
#Tuple Type
testTuple = (50,"100",True,50,"50")
#print(testTuple)
#print(len(testTuple))
#print(type(testTuple))
testSet = {50,"100",True,50,"50",50,100,100,"a"}
#print(testSet)
#print(len(testSet))
#print(type(testSet))
testDic = {"first":50,"second":"100","third":True,"a":50,"a":"LAST"}
#No Dups Ordered
print(testDic)
print(len(testDic))
print(type(testDic))
