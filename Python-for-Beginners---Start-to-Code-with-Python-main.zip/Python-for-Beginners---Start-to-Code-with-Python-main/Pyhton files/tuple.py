testTuple = ("Hello","Laurence","Svekis",100,True,"Svekis","Svekis")
val = len(testTuple)
print(testTuple)
#testTuple[2] = "NEW"
val = testTuple[2]
print(val)