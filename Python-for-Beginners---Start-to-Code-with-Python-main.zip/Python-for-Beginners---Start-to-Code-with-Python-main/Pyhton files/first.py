print("hello world")
#print(5+10)
#print(5+10) 
"""
print(5+10)
print(5+10) 
"""
print(5+10) 
print(5+10) #adding