myName = {
    "first" : "Laur",
    "last" : "Svekis",
    "status" : True
}