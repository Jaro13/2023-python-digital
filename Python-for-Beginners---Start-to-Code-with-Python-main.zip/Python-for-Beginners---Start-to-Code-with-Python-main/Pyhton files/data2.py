myName = {
    "first" : "Laurence",
    "last" : "Svekis",
    "status" : True
}