testSet = {"Svekis",100,True,"Svekis",100,"Laurence"}
testSet.add("New")
testSet.remove(100)
testSet.pop()
val = ("Svekis" in testSet)
print(testSet)
print(val)