def welcome(first,last):
    fullName = first + " " + last
    print("Welcome to my page, " + fullName)


def adder(a,b):
    return a + b

myName = {
    "first" : "John",
    "last" : "Vekis",
    "status" : True
}