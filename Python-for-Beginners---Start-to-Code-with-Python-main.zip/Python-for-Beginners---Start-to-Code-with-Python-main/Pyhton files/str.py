name = "    Laurence Svekis   "
val = len(name)
findThis = "SDe"
val = (findThis in name)
val = (findThis not in name)
val = name[0:5]
val = name[:5]
val = name[6:]
val = name.upper()
val = name.lower()
val = name.strip()
val = name.replace("e","").strip().upper()
val = name.strip().split(" ")
print(name)
val1 = '----'.join(val)
print(val)
print(val1)
