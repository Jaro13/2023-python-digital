num1 = int(input("First Number : "))
num2 = int(input("Second Number : "))
total = num1 + num2
cal = str(num1) + "+" + str(num2) + "=" + str(total)
message = "Your Total is " + str(total)
print(cal)
print(message)