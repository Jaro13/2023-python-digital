testList = ["Laurence","World","Hello","World"]
#a,b,c,d,e,f,g = testList
testList.insert(3,"Svekis")
#testList.append("End")
#testList.remove(100)
testList[0] = "New"
print(testList)
#val = testList.pop(3)
#del testList[1]
#del testList
#testList.clear()
testList.sort()
print(testList)
testList.reverse()
copyList = testList.copy()
copyList.append("NEW")
print(copyList)
print(testList)
#print(testList[2])
#print(c)
#print(len(testList))
#print(testList[-2])
#print(testList[1:2])
#print(testList[:3])
#print(testList.index(100))
#val = ("ASvekis" in testList)

#print(val)
