a = 5
b = 10
a += 3 # a = a + 3
print(a+b)
print(b-6)
print(4*5)
print(50/10)
print(53%10)
print(5 == 2)
print(5 > 2 and 10 < 5)
print(5 > 2 or 10 < 5)
print(not(50 > 5))
