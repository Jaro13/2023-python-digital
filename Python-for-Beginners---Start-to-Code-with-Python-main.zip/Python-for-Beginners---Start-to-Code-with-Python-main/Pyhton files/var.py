# Start with letter or _ cannot start with a number
# a-Z0-9_
a = 55
message = "Hello World"
print(a+b)
print(5+10)
print(message)
a = str(a)
print(type(a))
a = int(a)
print(type(a))
print(a)
str1 = "hello world"
str2 = 'hello'
str3 = "hello' world"
Str1 = "hello"
print(str1)
print(Str1)
outputMessage = "hello"
a, b, c = 5 , 10 , 15
print(c)
d = e = f = 50
print(e)
data = ["Laurence","John","Linda"]
g,h,i = data
print(h)