from app.create_app import create_application

app = create_application()
