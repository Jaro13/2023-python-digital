def celsius_to_fahrenheit(celsius_degrees):
    return celsius_degrees * 1.8 + 32

print("20°C = " + str(celsius_to_fahrenheit(20)) + "°F")
print("25°C = " + str(celsius_to_fahrenheit(25)) + "°F")
