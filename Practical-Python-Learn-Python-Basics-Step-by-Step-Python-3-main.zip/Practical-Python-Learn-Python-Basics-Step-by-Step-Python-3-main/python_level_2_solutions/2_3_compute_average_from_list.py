def compute_list_average(number_list):
    return sum(number_list) / len(number_list)

number_list = [3, 4, 5, 2]
print(compute_list_average(number_list))
