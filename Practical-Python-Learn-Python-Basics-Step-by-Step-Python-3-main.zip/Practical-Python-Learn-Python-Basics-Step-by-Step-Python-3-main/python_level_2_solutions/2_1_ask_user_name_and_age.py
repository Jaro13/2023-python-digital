def say_hello(user_name, user_age):
    print("Hello " + user_name + ", you are " + str(user_age))

user_name = input("What is your name? ")
user_age = input("How old are you? ")
say_hello(user_name, user_age)
